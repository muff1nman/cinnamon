package board;

public class WalkwayCell extends BoardCell {
	public WalkwayCell() {
		super();
	}
	@Override
	public boolean isWalkway() {
		return true;
	}
	@Override
	void draw() {
		// TODO Auto-generated method stub
		
	}

}
